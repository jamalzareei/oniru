<!--
To change this template, choose Tools | Templates
and open the template in the editor.
-->
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>دکوراسیون داخلی | اونیرو</title>
        <link href="css/bootstrap.min.css" rel="stylesheet"/>
        <link href="css/style.css" rel="stylesheet"/>

    </head>
    <body>
        <div class="container-fluid">

            <?php include 'MenuTop.php'; ?>

            <div class="row tab-1">
                <div class="col-md-12 affix top-heading">
                    <img class="img-heading" src="image/15151515-0707-1212135605news.jpg" alt="photos" width="100%" height="250"/>
                </div>
            </div>
            <div class="heading">
                <a href="">
                محصولات
                </a>
            </div>
            <div class="row tab-2-photo">
                <div class="col-md-12 padd-sefr">
                    <div class="row hr w-100">
                        <div class="col-md-1"></div>
                        <div class="col-md-10">
                            <div class="row">
                                <div class="col-md-6 photo-photo-php">
                                    <img alt="Bootstrap Image Preview" src="image/15151515-0707-1212135605news.jpg" class="img-thumbnail photos-photos">
                                    <div class="photo-full">
                                    </div>
                                    <div class="photo-title">
                                        <a href="#">آشپزخانه</a>
                                    </div>
                                </div>
                                <div class="col-md-6 photo-photo-php">
                                    <img alt="Bootstrap Image Preview" src="image/15151515-0707-1212135605news.jpg" class="img-thumbnail photos-photos">
                                    <div class="photo-full">
                                    </div>
                                    <div class="photo-title">
                                        <a href="#">اتاق خواب</a>
                                    </div>
                                </div>
                                <div class="col-md-6 photo-photo-php">
                                    <img alt="Bootstrap Image Preview" src="image/15151515-0707-1212135605news.jpg" class="img-thumbnail photos-photos">
                                    <div class="photo-full">
                                    </div>
                                    <div class="photo-title">
                                        <a href="#">نشیمن</a>
                                    </div>
                                </div>
                                <div class="col-md-6 photo-photo-php">
                                    <img alt="Bootstrap Image Preview" src="image/15151515-0707-1212135605news.jpg" class="img-thumbnail photos-photos">
                                    <div class="photo-full">
                                    </div>
                                    <div class="photo-title">
                                        <a href="#">نهار خوری</a>
                                    </div>
                                </div>
                                <div class="col-md-6 photo-photo-php">
                                    <img alt="Bootstrap Image Preview" src="image/15151515-0707-1212135605news.jpg" class="img-thumbnail photos-photos">
                                    <div class="photo-full">
                                    </div>
                                    <div class="photo-title">
                                        <a href="#">فضای باز</a>
                                    </div>
                                </div>
                                <div class="col-md-6 photo-photo-php">
                                    <img alt="Bootstrap Image Preview" src="image/15151515-0707-1212135605news.jpg" class="img-thumbnail photos-photos">
                                    <div class="photo-full">
                                    </div>
                                    <div class="photo-title">
                                        <a href="#">محل کار</a>
                                    </div>
                                </div>
                                <div class="col-md-6 photo-photo-php">
                                    <img alt="Bootstrap Image Preview" src="image/15151515-0707-1212135605news.jpg" class="img-thumbnail photos-photos">
                                    <div class="photo-full">
                                    </div>
                                    <div class="photo-title">
                                        <a href="#">دکور بیرون</a>
                                    </div>
                                </div>
                                <div class="col-md-6 photo-photo-php">
                                    <img alt="Bootstrap Image Preview" src="image/15151515-0707-1212135605news.jpg" class="img-thumbnail photos-photos">
                                    <div class="photo-full">
                                    </div>
                                    <div class="photo-title">
                                        <a href="#">پستو و انبار</a>
                                    </div>
                                </div>
                                <div class="col-md-6 photo-photo-php">
                                    <img alt="Bootstrap Image Preview" src="image/15151515-0707-1212135605news.jpg" class="img-thumbnail photos-photos">
                                    <div class="photo-full">
                                    </div>
                                    <div class="photo-title">
                                        <a href="#">اتاق کودک و نوجوان</a>
                                    </div>
                                </div>
                                <div class="col-md-6 photo-photo-php">
                                    <img alt="Bootstrap Image Preview" src="image/15151515-0707-1212135605news.jpg" class="img-thumbnail photos-photos">
                                    <div class="photo-full">
                                    </div>
                                    <div class="photo-title">
                                        <a href="#">حمام</a>
                                    </div>
                                </div>
                                <div class="col-md-6 photo-photo-php">
                                    <img alt="Bootstrap Image Preview" src="image/15151515-0707-1212135605news.jpg" class="img-thumbnail photos-photos">
                                    <div class="photo-full">
                                    </div>
                                    <div class="photo-title">
                                        <a href="#">دستشویی</a>
                                    </div>
                                </div>
                                <div class="col-md-6 photo-photo-php">
                                    <img alt="Bootstrap Image Preview" src="image/15151515-0707-1212135605news.jpg" class="img-thumbnail photos-photos">
                                    <div class="photo-full">
                                    </div>
                                    <div class="photo-title">
                                        <a href="#">بیشتر</a>
                                    </div>
                                </div>
                                <pre></pre>
                                <div class="hr"></div>
                                <pre>

                                <div class="text-center">Products</div>

                                </pre>
                                <div class="col-md-12">
                                    <div class="row">
                                        <div class="carousel slide" id="carousel-690377">
                                            <div class="carousel-inner">
                                                <div class="item active">
                                                    <div class="row">
                                                        <div class="col-md-4">
                                                            <img alt="Bootstrap Image Preview" src="image/15151515-0707-1212135605news.jpg" class="img-thumbnail">
                                                        </div>
                                                        <div class="col-md-4">
                                                            <img alt="Bootstrap Image Preview" src="image/15151515-0707-1212135605news.jpg" class="img-thumbnail">
                                                        </div>
                                                        <div class="col-md-4">
                                                            <img alt="Bootstrap Image Preview" src="image/15151515-0707-1212135605news.jpg" class="img-thumbnail">
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="item">
                                                    <div class="row">
                                                        <div class="col-md-4">
                                                            <img alt="Bootstrap Image Preview" src="image/15151515-0707-1212135605news.jpg" class="img-thumbnail">
                                                        </div>
                                                        <div class="col-md-4">
                                                            <img alt="Bootstrap Image Preview" src="image/15151515-0707-1212135605news.jpg" class="img-thumbnail">
                                                        </div>
                                                        <div class="col-md-4">
                                                            <img alt="Bootstrap Image Preview" src="image/15151515-0707-1212135605news.jpg" class="img-thumbnail">
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="item">
                                                    <div class="row">
                                                        <div class="col-md-4">
                                                            <img alt="Bootstrap Image Preview" src="image/15151515-0707-1212135605news.jpg" class="img-thumbnail">
                                                        </div>
                                                        <div class="col-md-4">
                                                            <img alt="Bootstrap Image Preview" src="image/15151515-0707-1212135605news.jpg" class="img-thumbnail">
                                                        </div>
                                                        <div class="col-md-4">
                                                            <img alt="Bootstrap Image Preview" src="image/15151515-0707-1212135605news.jpg" class="img-thumbnail">
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                            <a class="left carousel-control left-right left-photos" id="left-photos" href="#carousel-690377" data-slide="prev">
                                                <span class="glyphicon glyphicon-chevron-left"></span>
                                            </a>
                                            <a class="right carousel-control left-right right-photos" id="right-photos" href="#carousel-690377" data-slide="next">
                                                <span class="glyphicon glyphicon-chevron-right"></span>
                                            </a>
                                        </div>
                                    </div>
                                </div>

                                <pre></pre>
                                <div class="hr"></div>
                                <pre>


                                </pre>
                                <div class="col-md-12">
                                    <div class="row">
                                        <div class="carousel slide" id="carousel-690377">
                                            <div class="carousel-inner">
                                                <div class="item active">
                                                    <div class="row">
                                                        <div class="col-md-4">
                                                            <img alt="Bootstrap Image Preview" src="image/15151515-0707-1212135605news.jpg" class="img-thumbnail">
                                                        </div>
                                                        <div class="col-md-4">
                                                            <img alt="Bootstrap Image Preview" src="image/15151515-0707-1212135605news.jpg" class="img-thumbnail">
                                                        </div>
                                                        <div class="col-md-4">
                                                            <img alt="Bootstrap Image Preview" src="image/15151515-0707-1212135605news.jpg" class="img-thumbnail">
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="item">
                                                    <div class="row">
                                                        <div class="col-md-4">
                                                            <img alt="Bootstrap Image Preview" src="image/15151515-0707-1212135605news.jpg" class="img-thumbnail">
                                                        </div>
                                                        <div class="col-md-4">
                                                            <img alt="Bootstrap Image Preview" src="image/15151515-0707-1212135605news.jpg" class="img-thumbnail">
                                                        </div>
                                                        <div class="col-md-4">
                                                            <img alt="Bootstrap Image Preview" src="image/15151515-0707-1212135605news.jpg" class="img-thumbnail">
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="item">
                                                    <div class="row">
                                                        <div class="col-md-4">
                                                            <img alt="Bootstrap Image Preview" src="image/15151515-0707-1212135605news.jpg" class="img-thumbnail">
                                                        </div>
                                                        <div class="col-md-4">
                                                            <img alt="Bootstrap Image Preview" src="image/15151515-0707-1212135605news.jpg" class="img-thumbnail">
                                                        </div>
                                                        <div class="col-md-4">
                                                            <img alt="Bootstrap Image Preview" src="image/15151515-0707-1212135605news.jpg" class="img-thumbnail">
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                            <a class="left carousel-control left-right left-photos" id="left-photos" href="#carousel-690377" data-slide="prev">
                                                <span class="glyphicon glyphicon-chevron-left"></span>
                                            </a>
                                            <a class="right carousel-control left-right right-photos" id="right-photos" href="#carousel-690377" data-slide="next">
                                                <span class="glyphicon glyphicon-chevron-right"></span>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-1"></div>

                    </div>
                    <?php include 'footer.php'; ?>
                </div>
            </div>


        </div>
        <script src="js/jquery.min.js"></script>
        <script src="js/bootstrap.min.js"></script>
        <script src="js/scripts.js"></script>
    </body>
</html>
