<br>
<footer class="footer">
    <div class="row w-100">
        <div class="col-md-11">
            <div class="row">

                <div class="col-md-1">

                </div>
                <div class="col-md-3">
                    <p class="services4">
                        خبرنامه
                    </p>

                    <ul>
                        <li><a href="#">3D modeling</a></li>
                        <li><a href="#">Web development</a></li>
                        <li><a href="#">Mobile development</a></li>
                        <li><a href="#">Web &amp; Print Design</a></li>
                    </ul>
                </div>
                <div class="col-md-3">
                    <p class="services1">
                        خبرنامه
                    </p>

                    <ul>
                        <li><a href="#">3D modeling</a></li>
                        <li><a href="#">Web development</a></li>
                        <li><a href="#">Mobile development</a></li>
                        <li><a href="#">Web &amp; Print Design</a></li>
                    </ul>
                </div>
                <div class="col-md-3">
                    <p class="services2">
                        سرویسها
                    </p>

                    <ul>
                        <li><a href="#">3D modeling</a></li>
                        <li><a href="#">Web development</a></li>
                        <li><a href="#">Mobile development</a></li>
                        <li><a href="#">Web &amp; Print Design</a></li>
                    </ul>
                </div>
                <div class="col-md-2">
                    <div class="row">
                        <div class="col-md-12 text-center">
                            <img src="image/15151515-0707-1212140055news.jpg" class="img-circle" alt="" width="140px" height="140px"/>
                        </div>

                        <div class="col-md-12 soasial">
                            <img src="img/sosial/Facebook.png" class="img-circle" alt="" width="15%" height=""/>
                            <img src="img/sosial/Twitter.png" class="img-circle" alt="" width="15%" height=""/>
                            <img src="img/sosial/Google+.png" class="img-circle" alt="" width="15%" height=""/>
                            <img src="img/sosial/Linkedin.png" class="img-circle" alt="" width="15%" height=""/>
                            <img src="img/sosial/Facebook.png" class="img-circle" alt="" width="15%" height=""/>
                            <img src="img/sosial/Rss.png" class="img-circle" alt="" width="15%" height=""/>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-1"></div>
    </div>
    <div class="copy-right hr">
        Copyright© 2015 by ONIRU.IR
    </div>
    <br>
</footer>
